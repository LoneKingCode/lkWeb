﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lkWeb.Areas.Admin.Models
{
    public class SetColumnAttrModel
    {
        public string FiledName { get; set; }
        public string Value { get; set; }
    }
}
