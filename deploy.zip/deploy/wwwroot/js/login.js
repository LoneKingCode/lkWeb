﻿$(function () {
    $("#loginForm").validate(
        {

        }
    )
})