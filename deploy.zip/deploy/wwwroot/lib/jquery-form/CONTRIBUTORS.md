#Contributors

###Copyright 2017 Kevin Morris
Continuing Work [jQuery Form](https://github.com/jquery-form/form/) by Kevin Morris  
Project Home: [github.com/jquery-form/form](https://github.com/jquery-form/form/)  

###Copyright 2006-2014 Mike Alsup
Original work [jQuery Form](https://github.com/malsup/form/) by Mike Alsup  
Project Home: [jquery.malsup.com/form](http://jquery.malsup.com/form/)  
The jQuery Form Plugin allows you to easily and unobtrusively upgrade HTML forms to use AJAX.  
